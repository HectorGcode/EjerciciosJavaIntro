/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demoegg;

/**
 *
 * @author imolero
 */
public class S01Ejercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre = "Juan";
        boolean bandera = false;
        char charac = 'a';
        short valor = 16;
        int entero = 1546;
        long enteroLargo = 1522458875;
    }
    
}
