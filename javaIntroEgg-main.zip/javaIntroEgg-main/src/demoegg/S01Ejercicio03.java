/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demoegg;

/**
 *
 * @author imolero
 */
public class S01Ejercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int int1 = 15;
        int int2 = 25;
        
        boolean compara = int1 > int2;
        boolean compar = int2 <= int1;
        
        int int3 = int1 + int2;
        int int4 = int1 - int2;
        
        int1++;
        int2--;
        
        System.out.println(int1);
        System.out.println(int2);
        System.out.println(int3);
        System.out.println(int4);
    }
    
}
